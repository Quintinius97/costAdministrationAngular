describe('Web Engineering', function () {
  /*beforeEach(function () {
    browser.get('http://localhost:3000/index.html#!/week');
  });

  it('should display initial events', function () {
    var events = element.all(by.tagName('event'));
    expect(events.count()).toEqual(2);

    expect(events.get(0).getText()).toContain('Christmas Feast');
    expect(events.get(1).getText()).toContain('New Year');
  });
*/
});
